window.onload = () => {
  console.log("Welcome to Adam Is Academy 🎓");
};
